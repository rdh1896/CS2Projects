package common;

public class WAMMain {
}
