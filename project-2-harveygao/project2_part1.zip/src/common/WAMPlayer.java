package common;

public class WAMPlayer {
}
