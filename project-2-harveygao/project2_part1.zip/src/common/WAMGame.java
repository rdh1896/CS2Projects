package common;

public class WAMGame {
}
