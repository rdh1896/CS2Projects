package client.gui;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.Scene;

import java.util.List;

public class WAMUI extends Application implements Observer<WAMBoard> {

    private Scene scene;
    private Stage stage;
    private WAMBoard model;
    private WAMNetworkClient server;
    public final Image TEMP = new Image(getClass().getResourceAsStream(""));
    public BorderPane access;
    public GridPane getGrid;

    /**
     * Initializes the model and the client-side connection, and adds itself as an
     * observer to the model.
     */
    @Override
    public void init () {

        try {
            // get the command line args
            List<String> args = getParameters().getRaw();

            // get host info and port from command line
            String host = args.get(0);
            int port = Integer.parseInt(args.get(1));

            // create the server connection
            this.server = new WAMNetworkClient(host, port);
            this.server.startListener();

            while (this.server.getModel() == null) {
                assert true;
            }

            // get board format from server
            this.model = server.getModel();
            this.model.addObserver(this);



        } catch(NumberFormatException e) {
            System.err.println(e);
            throw new RuntimeException(e);
        }

    }

    /**
     * Creates the interface for the game.
     *
     * The mole holes are represented by a GridPane. The main game board is a BorderPane:
     * the gridpane goes in the center, a label representing game status goes on the
     * the top, and the scores for each of the players goes on the right.
     *
     * @param stage stage
     */
    public void start (Stage stage) {

        int columns = model.getCols();
        int rows = model.getRows();
        int numPlayers = model.getNumOfPlayers();

        BorderPane mainInterface = new BorderPane();
        GridPane moleGrid = new GridPane();
        VBox scoreBoard = new VBox(5);

        for (int i = 0; i < numPlayers; i++){
            Label newLabel = new Label("Score: ");
            scoreBoard.getChildren().add(newLabel);
        }


        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < columns; c++) {
                Button button = new Button();
                button.setMaxSize(64, 64);
                button.setMinSize(64, 64);

                /*
                button.setOnAction(ActionEvent -> {
                }); */

                /**
                Image img = new Image("client/gui/empty.png");
                button.setGraphic(new ImageView(img));

                moleGrid.add(button, c, r);
                 **/

                button.setText("D");
                moleGrid.add(button, c, r);
            }
        }

            Label gameStatus = new Label("Game Status: Waiting for connection ...");

            //Score, main board, and game status message has been set. Probably should
            //add a countdown timer for the length of the game as well.
            mainInterface.setCenter(moleGrid);
            mainInterface.setTop(gameStatus);
            mainInterface.setRight(scoreBoard);

            this.scene = new Scene(mainInterface);

            this.access = mainInterface;
            this.getGrid = moleGrid;

            stage.setTitle("Whack-A-Mole!");
            stage.setScene(scene);
            stage.show();

    }

    /**
     * Ends the network connection when the GUI is closed.
     */
    @Override
    public void stop () {
        //Need a close method in WAMNetworkClient
    }

    /**
     * Changes the GUI view depending on the changes in the model. If the game
     * has been ended in any way (WIN, LOSE, TIE, ERROR), it notifies the player.
     * Otherwise if the game continues to run, it iterates through each mole hole
     * to check if any moles are popping up or going down, and updates accordingly.
     */
    public void refresh () {
        switch (this.model.getStatus()) {
            case RUNNING:
                // Redraw board, check each mole's boolean value.
                // If true, set to UP. If false, set to down.
                // Use counter to keep track of moles.

                access.setTop(new Label("Whack those moles!!!"));

                int moleIndex;

                int itrRow = 1;

                int rows = model.getRows();
                int cols = model.getCols();

                for (int r = 0; r < rows; r++){
                    for(int c = 0; c < cols; c++){
                        moleIndex = (r*cols) + c;
                        if(model.getMole(moleIndex)){
                            System.out.println("Testing up");
                            /**
                            Image moleUP = new Image("client/gui/up.png");
                            getGrid.add(new ImageView(moleUP), r, c);
                             **/
                            Button b = new Button("U");
                            getGrid.add(b, c, r);
                        }
                        else {
                            System.out.println("Testing down");
                            /**
                            Image moleDOWN = new Image("client/gui/empty.png");
                            getGrid.add(new ImageView(moleDOWN), r, c);
                             **/
                            Button b = new Button("D");
                            getGrid.add(b, c, r);
                        }
                    }
                    itrRow++;
                }

            case WON:
                access.setTop(new Label("You won! Awesome!"));
                break;
            case LOST:
                access.setTop(new Label("You lost! Aww!"));
                break;
            case TIE:
                access.setTop(new Label("The game has been tied!"));
                break;
            case ERROR:
                access.setTop(new Label("Uh oh, we encountered an error."));
                break;
        }
    }

    /**
     * Called by the model when the view needs to be updated.
     * @param wamBoard The board calling the update method.
     */
    @Override
    public void update (WAMBoard wamBoard) {
        if ( Platform.isFxApplicationThread() ) {
            this.refresh();
        }
        else {
            Platform.runLater( () -> this.refresh() );
        }
    }

    /**
     * The main expects the host and port as command line args.
     * @param args Host and port.
     */
    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java WAMUI host port");
            System.exit(-1);
        } else {
            Application.launch(args);
        }
    }
}
